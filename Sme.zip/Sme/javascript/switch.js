function checkDay() {
    let day = Number(document.getElementById("day").value);

    switch (day) {
        case 1:
            document.getElementById("result").innerText = "Monday";
            break;

        case 2:
            document.getElementById("result").innerText = "Tuesday";
            break;

        case 3:
            document.getElementById("result").innerText = "Wednesday";
            break;

        case 4:
            document.getElementById("result").innerText = "Thursday";
            break;

        case 5:
            document.getElementById("result").innerText = "Friday";
            break;

        case 6:
            document.getElementById("result").innerText = "Saturday";
            break;

        case 7:
            document.getElementById("result").innerText = "Sunday";
            break;

        default:
            document.getElementById("result").innerText = "Invalid Day";
    }
}
