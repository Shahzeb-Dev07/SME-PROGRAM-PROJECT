// ===== Employee Management System =====
const API_URL = "https://dummyjson.com/users";
// All data lives in the browser's LocalStorage. No backend, no APIs.

const STORAGE_KEY = "ems_employees";
const PER_PAGE = 10;
const DEPARTMENTS = ["IT", "Human Resources", "Marketing", "Finance", "Sales", "Design", "Operations"];
const FIELDS = ["name", "email", "phone", "empId", "position", "department", "joined", "status", "address"];

let employees = [];     // all saved employees
let currentPage = 1;
let editingId = null;   // ID of the employee being edited (null = adding new)
let confirmAction = null;

const $ = (id) => document.getElementById(id);

// ---------- Sample data ----------
function daysAgo(n) {
  const d = new Date();
  d.setDate(d.getDate() - n);
  return d.toISOString().slice(0, 10);
}


function getSampleData() {
  return [
    { id: "EMP-001", name: "prince", email: "sarah.mitchell@company.com", phone: "+1 555 010 1001", position: "Engineering Manager", department: "IT", joined: daysAgo(1100), status: "Active", address: "12 Oak Street, Austin, TX" },
    { id: "EMP-002", name: "yash", email: "david.chen@company.com", phone: "+1 555 010 1002", position: "HR Specialist", department: "Human Resources", joined: daysAgo(640), status: "Active", address: "" },
    { id: "EMP-003", name: "Ansuman", email: "priya.sharma@company.com", phone: "+91 98765 43210", position: "Marketing Lead", department: "Marketing", joined: daysAgo(420), status: "Active", address: "45 Lake View Road, Pune" },
    { id: "EMP-004", name: "Vani", email: "james.carter@company.com", phone: "+1 555 010 1004", position: "Financial Analyst", department: "Finance", joined: daysAgo(260), status: "Inactive", address: "" },
    { id: "EMP-005", name: "Ram", email: "elena.rossi@company.com", phone: "+39 06 1234 5678", position: "Sales Executive", department: "Sales", joined: daysAgo(120), status: "Active", address: "Via Roma 10, Rome" },
    { id: "EMP-006", name: "Mohib", email: "omar.haddad@company.com", phone: "+1 555 010 1006", position: "UI/UX Designer", department: "Design", joined: daysAgo(18), status: "Active", address: "" },
    { id: "EMP-007", name: "Akhlad", email: "grace.okafor@company.com", phone: "+234 802 123 4567", position: "Operations Coordinator", department: "Operations", joined: daysAgo(6), status: "Active", address: "" }
  ];
}


// ---------- LocalStorage ----------
function saveEmployees() {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(employees));
}

async function loadEmployees() {
    try {
        const response = await fetch(API_URL);

        if (!response.ok) {
            throw new Error("API request failed");
        }

        const result = await response.json();

        employees = result.users.map((user) => ({
            id: "EMP-" + String(user.id).padStart(3, "0"),
            apiId: user.id,
            name: user.firstName + " " + user.lastName,
            email: user.email,
            phone: user.phone,
            position: user.company.title,
            department: user.company.department,
            joined: daysAgo(0),
            status: "Active",
            address: user.address.address
        }));

        currentPage = 1;
        renderAll();

    } catch (error) {
        console.error("API Error:", error);
        showToast("Employees load nahi hue. API check karo.", true);
    }
}

// ---------- Small helpers ----------
// Builds an element and sets text with textContent (safe for user input).
function el(tag, text, className) {
  const node = document.createElement(tag);
  if (text !== undefined) node.textContent = text;
  if (className) node.className = className;
  return node;
}

function formatDate(value) {
  const d = new Date(value + "T00:00:00");
  return isNaN(d) ? "—" : d.toLocaleDateString(undefined, { day: "numeric", month: "short", year: "numeric" });
}

let toastTimer;
function showToast(message, isError) {
  const toast = $("toast");
  toast.textContent = message;
  toast.className = "toast show" + (isError ? " error" : "");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => toast.classList.remove("show"), 3000);
}

function generateId() {
  let max = 0;
  employees.forEach((e) => {
    const match = /^EMP-(\d+)$/i.exec(e.id);
    if (match) max = Math.max(max, Number(match[1]));
  });
  return "EMP-" + String(max + 1).padStart(3, "0");
}

// ---------- Filtering, sorting, rendering ----------
function getVisibleEmployees() {
  const q = $("search").value.trim().toLowerCase();
  const dept = $("filterDept").value;
  const status = $("filterStatus").value;
  const sortBy = $("sortBy").value;

  const list = employees.filter((e) =>
    (!q || [e.name, e.id, e.email].some((v) => v.toLowerCase().includes(q))) &&
    (!dept || e.department === dept) &&
    (!status || e.status === status)
  );

  list.sort((a, b) => {
    if (sortBy === "joined") return b.joined.localeCompare(a.joined);
    if (sortBy === "department") return a.department.localeCompare(b.department) || a.name.localeCompare(b.name);
    return a.name.localeCompare(b.name);
  });
  return list;
}

function renderStats() {
  const cutoff = daysAgo(30);
  $("statTotal").textContent = employees.length;
  $("statDepts").textContent = new Set(employees.map((e) => e.department)).size;
  $("statActive").textContent = employees.filter((e) => e.status === "Active").length;
  $("statRecent").textContent = employees.filter((e) => e.joined >= cutoff).length;
}

function makeActionButton(label, ariaLabel, onClick) {
  const btn = el("button", label, "btn btn-secondary btn-sm");
  btn.type = "button";
  btn.setAttribute("aria-label", ariaLabel);
  btn.addEventListener("click", onClick);
  return btn;
}

function renderTable() {
  const list = getVisibleEmployees();
  const totalPages = Math.max(1, Math.ceil(list.length / PER_PAGE));
  currentPage = Math.min(currentPage, totalPages);
  const pageItems = list.slice((currentPage - 1) * PER_PAGE, currentPage * PER_PAGE);

  const body = $("tableBody");
  body.replaceChildren();

  pageItems.forEach((emp) => {
    const row = document.createElement("tr");
    row.append(
      el("td", emp.id),
      el("td", emp.name, "name"),
      el("td", emp.email),
      el("td", emp.phone),
      el("td", emp.position),
      el("td", emp.department),
      el("td", formatDate(emp.joined))
    );

    const statusCell = document.createElement("td");
    statusCell.append(el("span", emp.status, "badge " + emp.status.toLowerCase()));
    row.append(statusCell);

    const actionCell = document.createElement("td");
    const actions = el("div", undefined, "actions");
    actions.append(
      makeActionButton("View", "View " + emp.name, () => openView(emp.id)),
      makeActionButton("Edit", "Edit " + emp.name, () => openForm(emp.id)),
      makeActionButton("Delete", "Delete " + emp.name, () => askDelete(emp.id))
    );
    actionCell.append(actions);
    row.append(actionCell);
    body.append(row);
  });

  $("tableWrap").hidden = list.length === 0;
  $("emptyState").hidden = list.length !== 0;
  $("resultCount").textContent = `Showing ${pageItems.length} of ${list.length} employees`;
  $("pageInfo").textContent = `Page ${currentPage} of ${totalPages}`;
  $("prevBtn").disabled = currentPage <= 1;
  $("nextBtn").disabled = currentPage >= totalPages;
}

function renderAll() {
  renderStats();
  renderTable();
}

// ---------- Modals ----------
function closeParentDialog(event) {
  event.target.closest("dialog").close();
}

function openView(id) {
  const emp = employees.find((e) => e.id === id);
  if (!emp) return;
  const rows = [
    ["Employee ID", emp.id], ["Full Name", emp.name], ["Email", emp.email], ["Phone Number", emp.phone],
    ["Position", emp.position], ["Department", emp.department], ["Joining Date", formatDate(emp.joined)],
    ["Employment Status", emp.status]
  ];
  if (emp.address) rows.push(["Address", emp.address]);

  const list = $("viewBody");
  list.replaceChildren();
  rows.forEach(([label, value]) => {
    const wrap = el("div", undefined, label === "Address" ? "full" : "");
    wrap.append(el("dt", label), el("dd", value));
    list.append(wrap);
  });
  $("viewModal").showModal();
}

function askConfirm(title, message, buttonLabel, action) {
  $("confirmTitle").textContent = title;
  $("confirmText").textContent = message;
  $("confirmYes").textContent = buttonLabel;
  confirmAction = action;
  $("confirmModal").showModal();
}

function askDelete(id) {
  const emp = employees.find((e) => e.id === id);
  if (!emp) return;

  askConfirm(
    "Delete employee?",
    `${emp.name} will be permanently removed. This cannot be undone.`,
    "Delete",
    async () => {
      try {
       

        const response = await fetch(
          `https://dummyjson.com/users/${emp.apiId}`,
          {
            method: "DELETE"
          }
        );

        if (!response.ok && response.status !== 404) {
    throw new Error("Delete API request failed");
}

        const result = await response.json();
        console.log("DELETE API response:", result);

        employees = employees.filter((e) => e.id !== id);

        saveEmployees();
        renderAll();
        showToast("Employee deleted successfully.");
      } catch (error) {
        console.error("DELETE API Error:", error);
        showToast("Employee delete API failed.", true);
      }
    }
  );
}

// ---------- Add / Edit form ----------
function clearErrors() {
  FIELDS.forEach((f) => {
    if ($("e-" + f)) $("e-" + f).textContent = "";
    $("f-" + f).classList.remove("invalid");
  });
}

function openForm(id) {
  clearErrors();
  $("employeeForm").reset();
  editingId = id || null;
 console.log("Editing employee:", id);
  const emp = id ? employees.find((e) => e.id === id) : null;

  $("formTitle").textContent = emp ? "Edit Employee" : "Add New Employee";
  $("saveBtn").textContent = emp ? "Save Changes" : "Save Employee";
  if (emp) {
    $("f-name").value = emp.name;
    $("f-email").value = emp.email;
    $("f-phone").value = emp.phone;
    $("f-empId").value = emp.id;
    $("f-position").value = emp.position;
    $("f-department").value = emp.department;
    $("f-joined").value = emp.joined;
    $("f-status").value = emp.status;
    $("f-address").value = emp.address || "";
  } else {
    $("f-joined").value = daysAgo(0);
  }
  $("formModal").showModal();
  $("f-name").focus();
}

// Returns an object of { field: "error message" } (empty if everything is valid).
function validateForm(data) {
  const errors = {};
  const phoneDigits = data.phone.replace(/\D/g, "");

  if (data.name.length < 2) errors.name = "Enter the employee's full name.";
  if (!data.email) errors.email = "Email address is required.";
  else if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(data.email)) errors.email = "Enter a valid email, like name@company.com.";
  else if (employees.some((e) => e.id !== editingId && e.email.toLowerCase() === data.email.toLowerCase())) errors.email = "Another employee already uses this email.";

  if (!data.phone) errors.phone = "Phone number is required.";
  else if (!/^[+]?[\d\s().-]+$/.test(data.phone) || phoneDigits.length < 7 || phoneDigits.length > 15) errors.phone = "Enter 7–15 digits. You may use +, spaces, ( ) and -.";

  if (data.empId && !/^[A-Za-z0-9-]+$/.test(data.empId)) errors.empId = "Use only letters, numbers and hyphens.";
  else if (data.empId && employees.some((e) => e.id !== editingId && e.id.toLowerCase() === data.empId.toLowerCase())) errors.empId = "This employee ID is already taken.";

  if (!data.position) errors.position = "Position is required.";
  if (!data.department) errors.department = "Choose a department.";
  if (!data.joined) errors.joined = "Joining date is required.";
  return errors;
}

async function handleFormSubmit(event) {
  event.preventDefault();
  console.log("SaveButtonClicked");
  const data = {};
  FIELDS.forEach((f) => (data[f] = $("f-" + f).value.trim()));

  clearErrors();
  const errors = validateForm(data);
  const errorFields = Object.keys(errors);
  if (errorFields.length > 0) {
    errorFields.forEach((f) => {
      $("e-" + f).textContent = errors[f];
      $("f-" + f).classList.add("invalid");
    });
    $("f-" + errorFields[0]).focus();
    showToast("Please fix the highlighted fields.", true);
    return;
  }
  const record = {
  id: data.empId || generateId(),
  name: data.name,
  email: data.email,
  phone: data.phone,
  position: data.position,
  department: data.department,
  joined: data.joined,
  status: data.status,
  address: data.address
};

 if (!editingId) {
  try {
    const response = await fetch(
      "https://dummyjson.com/users/add",
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          firstName: data.name,
          lastName: "",
          email: data.email,
          phone: data.phone,
          company: {
            title: data.position,
            department: data.department
          }
        })
      }
    );

    if (!response.ok) {
      throw new Error("POST API request failed");
    }

    const result = await response.json();
    record.apiId = result.id;

  } catch (error) {
    console.error("POST API Error:", error);
    showToast("Employee add API failed.", true);
    return;
  }
}

 if (editingId) {
  try {
    console.log("Selected employee:", employees.find((e) => e.id === editingId));
   const response = await fetch(
  `https://dummyjson.com/users/${employees.find((e) => e.id === editingId).apiId}`,
  {
    method: "PUT",
    headers: {
      "Content-Type": "application/json"
    },
    body: JSON.stringify({
      firstName: data.name,
      email: data.email,
      phone: data.phone,
      company: {
        title: data.position,
        department: data.department
      }
    })
  }
);

    if (!response.ok) {
  if (response.status === 404) {
    const current = employees.find((e) => e.id === editingId);

    record.apiId = current.apiId;

    employees = employees.map((e) =>
      e.id === editingId ? record : e
    );

    saveEmployees();
    $("formModal").close();
    renderAll();

    showToast("Updated locally. DummyJSON demo data is not permanent.");
    return;
  }

  throw new Error(
    `PUT API request failed: ${response.status} ${response.statusText}`
  );
}
    

    const result = await response.json();
    console.log("PUT API response:", result);

    employees = employees.map((e) =>
      e.id === editingId ? record : e
    );

    showToast("Employee updated successfully.");

  } catch (error) {
    console.error("PUT API Error:", error);
    showToast("Employee update API failed.", true);
    return;
  }

} else {
  employees.push(record);
  showToast("Employee added successfully.");
}
  saveEmployees();
  $("formModal").close();
  renderAll();
}

// ---------- Setup ----------
function fillDepartmentLists() {
  DEPARTMENTS.forEach((name) => {
    $("filterDept").append(new Option(name, name));
    $("f-department").append(new Option(name, name));
  });
}

function clearFilters() {
  $("search").value = "";
  $("filterDept").value = "";
  $("filterStatus").value = "";
  $("sortBy").value = "name";
  currentPage = 1;
  renderTable();
}

async function setup() {
  fillDepartmentLists();
  await loadEmployees();

  $("addBtn").addEventListener("click", () => openForm());
  $("employeeForm").addEventListener("submit", handleFormSubmit);
  document.querySelectorAll("[data-close]").forEach((btn) => btn.addEventListener("click", closeParentDialog));

  ["search", "filterDept", "filterStatus", "sortBy"].forEach((id) => {
    $(id).addEventListener("input", () => { currentPage = 1; renderTable(); });
  });
  $("clearBtn").addEventListener("click", clearFilters);
  $("prevBtn").addEventListener("click", () => { currentPage--; renderTable(); });
  $("nextBtn").addEventListener("click", () => { currentPage++; renderTable(); });

  $("confirmYes").addEventListener("click", () => {
    $("confirmModal").close();
    if (confirmAction) confirmAction();
    confirmAction = null;
  });
  $("resetDataBtn").addEventListener("click", () => {
    askConfirm("Reset sample data?", "All current employees will be replaced with the sample data.", "Reset", () => {
      employees = getSampleData();
      saveEmployees();
      clearFilters();
      renderAll();
      showToast("Sample data restored.");
    });
  });

  renderAll();
}

setup();
